package com.example.docker;

import org.springframework.data.mongodb.repository.MongoRepository;


public interface repository extends MongoRepository<topic,Integer> {

}
