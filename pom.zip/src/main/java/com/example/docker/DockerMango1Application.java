package com.example.docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerMango1Application {

	public static void main(String[] args) {
		SpringApplication.run(DockerMango1Application.class, args);
	}

}
