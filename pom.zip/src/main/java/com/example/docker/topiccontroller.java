package com.example.docker;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class topiccontroller {
	@Autowired
	private repository repo;
	
	@GetMapping("/alltopics")
	public List<topic> getalltopics(){
		return repo.findAll();
	}
	@PostMapping("/topics")
	public String addtopics(@RequestBody topic topic) {
		repo.save(topic);
		return "topic added successfully";
	}
	@GetMapping("/topic/{id}")
	public Optional<topic> gettopic(@PathVariable int id) {
		return repo.findById(id);
	}
	
	@DeleteMapping("/detopic/{id}")
	public String deletetopic(@PathVariable int id) {
		repo.deleteById(id);
		return "deleted successful";
	}
	@PutMapping("/update/{id}")
	public String updatetopic(@PathVariable int id,@RequestBody topic topics) {
		Optional<topic> t= repo.findById(id);
		
		if(t.isPresent()) {
		topic topic1=t.get();
		topic1.setName(topics.getName());
		topic1.setBranch(topics.getBranch());
		repo.save(topic1);
		return "updated successfully";
		}
		else {
			return "Not found";
		}
		
	}

}

